package com.doorman.porteirointeligente.model;

public class Resposta {

    private String resp;


    public void Resposta(){

    }

    public String getResp() {
        return resp;
    }

    public void setResp(String resp) {
        this.resp = resp;
    }


}
