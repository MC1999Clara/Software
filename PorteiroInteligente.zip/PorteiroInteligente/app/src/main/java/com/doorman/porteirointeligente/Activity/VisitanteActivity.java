package com.doorman.porteirointeligente.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.doorman.porteirointeligente.R;

import com.doorman.porteirointeligente.config.ConfiguracaoFirebase;
import com.doorman.porteirointeligente.helper.Preferencias;
import com.doorman.porteirointeligente.model.Contato;
import com.doorman.porteirointeligente.model.Usuario;
import com.doorman.porteirointeligente.model.Visitante;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class VisitanteActivity extends AppCompatActivity {

    private DatabaseReference referecia = FirebaseDatabase.getInstance().getReference();

    public EditText nomeVisi;
    private EditText bloco;
    private EditText apVisi;
    private Button notificar;
    private DatabaseReference sim;
    private DatabaseReference nao;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_visitante);




        nomeVisi = (EditText) findViewById(R.id.edit_visi_nome);
        bloco = (EditText) findViewById(R.id.edit_visi_bloco);
        apVisi = (EditText) findViewById(R.id.edit_visi_ap);
        notificar = (Button) findViewById(R.id.btn_notif);




        notificar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

             DatabaseReference visitantes =  referecia.child("visitantes");

               //Recuperar identificador usuario logado (base64)
               Preferencias preferencias = new Preferencias(VisitanteActivity.this);

               final String identificadorUsuarioLogi = preferencias.getIdentificador();
                 //String identificadorUsuarioLogi = preferencias.getIdentificador();

                Visitante visitant = new Visitante();

                visitant.setNome(nomeVisi.getText().toString());
                visitant.setBloco(bloco.getText().toString());
                visitant.setAp(apVisi.getText().toString());

               visitantes.child(identificadorUsuarioLogi).setValue(visitant);

                //Instanciar AlertDialog
                AlertDialog.Builder dialog = new AlertDialog.Builder(VisitanteActivity.this);

                //Configurar titulo e mensagem
                dialog.setTitle("Notificação de entrada enviada com sucesso");
                dialog.setMessage("Aguarde a resposta do morador!");

                //Configurar cancelamento
                dialog.setCancelable(false);

                //Configurar icone
                // dialog.setIcon(android.R.drawable.ic_btn_speak_now);

                //Configura acoes para sim e nao
                dialog.setPositiveButton("ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        Toast.makeText(
                                getApplicationContext(),
                                "Aguarde...",
                                Toast.LENGTH_SHORT
                        ).show();



                    }
                });

                //Criar e exibir AlertDialog
                dialog.create();
                dialog.show();



                visitantes.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {


                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });



            }

        });

        ///////////Resposta NAO/////////////////////

        //Recuperar instância Firebase
        nao= ConfiguracaoFirebase.getFirebase().child("respostanaovisi").child("001");

        nao.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.getValue() != null) {
                    //Instanciar AlertDialog
                    AlertDialog.Builder dialog = new AlertDialog.Builder(VisitanteActivity.this);


                    //Configurar titulo e mensagem
                    dialog.setTitle("Solicitação de entrada negada!");
                    dialog.setMessage("Verifique se o apartamento e bloco estão corretos!");

                    //Configurar cancelamento
                    dialog.setCancelable(false);

                    //Configura acoes para sim e nao
                    dialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            Toast.makeText(
                                    getApplicationContext(),
                                    "Tente novamente!",
                                    Toast.LENGTH_SHORT
                            ).show();



                        }
                    });

                    //Criar e exibir AlertDialog
                    dialog.create();
                    dialog.show();


                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

          ///////////////RESPOSTA SIM////////////////////////

//Recuperar instância Firebase
        sim= ConfiguracaoFirebase.getFirebase().child("respostasimvisi").child("001");

        sim.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.getValue() != null) {
                    //Instanciar AlertDialog
                    AlertDialog.Builder dialog = new AlertDialog.Builder(VisitanteActivity.this);


                    //Configurar titulo e mensagem
                    dialog.setTitle("Entrada liberada!");
                    dialog.setMessage("Clique no OK para abrir o portão!");

                    //Configurar cancelamento
                    dialog.setCancelable(false);

                    //Configura acoes para sim e nao
                    dialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            Toast.makeText(
                                    getApplicationContext(),
                                    "Seja Bem Vindo!",
                                    Toast.LENGTH_SHORT
                            ).show();



                        }
                    });

                    //Criar e exibir AlertDialog
                    dialog.create();
                    dialog.show();


                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

                }


    }





