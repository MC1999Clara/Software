package com.doorman.porteirointeligente.model;

public class Respnao {

    private String resp;


    public void Respnao(){

    }

    public String getResp() {
        return resp;
    }

    public void setResp(String resp) {
        this.resp = resp;
    }
}
