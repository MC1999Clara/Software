package com.doorman.porteirointeligente.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.doorman.porteirointeligente.R;
import com.doorman.porteirointeligente.config.ConfiguracaoFirebase;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

public class MoradorActivity extends AppCompatActivity {

    private Button pedes;
    private  Button carro;
    private DatabaseReference digital;
    private DatabaseReference ped;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_morador);

        pedes = (Button) findViewById(R.id.btn_pedes);
        carro = (Button) findViewById(R.id.btn_veicu);

        carro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Toast.makeText(
                        getApplicationContext(),
                        "Coloque seu dedo no leitor biometrico para liberar a cancela!",
                        Toast.LENGTH_SHORT
                ).show();

                }


        });

        pedes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Toast.makeText(
                        getApplicationContext(),
                        "Coloque seu dedo no leitor biometrico para abrir o portão!",
                        Toast.LENGTH_SHORT
                ).show();

            }


        });

//Recuperar instância Firebase
        digital= ConfiguracaoFirebase.getFirebase().child("Digital");

        digital.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                if (dataSnapshot.getValue() != null) {
                    //Instanciar AlertDialog
                    AlertDialog.Builder dialog = new AlertDialog.Builder(MoradorActivity.this);

                    //Configurar titulo e mensagem
                    dialog.setTitle("Biometria lida com sucesso! ");
                    dialog.setMessage("Aguarde que a cancela será aberta!");

                    //Configurar cancelamento
                    dialog.setCancelable(false);


                    //Configura acoes para sim e nao
                    dialog.setPositiveButton("ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            Toast.makeText(
                                    getApplicationContext(),
                                    "Cancela aberta",
                                    Toast.LENGTH_SHORT
                            ).show();


                        }
                    });

                    //Criar e exibir AlertDialog
                    dialog.create();
                    dialog.show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }

            });

        ped =ConfiguracaoFirebase.getFirebase().child("pedes");

        ped.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                if (dataSnapshot.getValue() != null) {
                    //Instanciar AlertDialog
                    //Instanciar AlertDialog
                    AlertDialog.Builder dialog = new AlertDialog.Builder(MoradorActivity.this);

                    //Configurar titulo e mensagem
                    dialog.setTitle("Biometria lida com sucesso!");
                    dialog.setMessage("Aguarde que o portão será aberto!");

                    //Configurar cancelamento
                    dialog.setCancelable(false);



                    //Configura acoes para sim e nao
                    dialog.setPositiveButton("ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            Toast.makeText(
                                    getApplicationContext(),
                                    "Portão aberto",
                                    Toast.LENGTH_SHORT
                            ).show();



                        }
                    });

                    //Criar e exibir AlertDialog
                    dialog.create();
                    dialog.show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        }
    }