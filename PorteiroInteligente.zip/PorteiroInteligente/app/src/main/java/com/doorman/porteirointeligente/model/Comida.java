package com.doorman.porteirointeligente.model;

public class Comida {
    private String bloco;
    private String ap;


    public Comida(){

    }

    public String getBloco() {
        return bloco;
    }

    public void setBloco(String bloco) {
        this.bloco = bloco;
    }

    public String getAp() {
        return ap;
    }

    public void setAp(String ap) {
        this.ap = ap;
    }
}
