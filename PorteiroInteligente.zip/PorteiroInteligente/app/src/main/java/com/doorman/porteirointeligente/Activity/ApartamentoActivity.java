package com.doorman.porteirointeligente.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AlertDialogLayout;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.viewpager.widget.ViewPager;

import com.doorman.porteirointeligente.Adapter.TabAdapter;
import com.doorman.porteirointeligente.R;
import com.doorman.porteirointeligente.config.ConfiguracaoFirebase;
import com.doorman.porteirointeligente.helper.Base64Custom;
import com.doorman.porteirointeligente.helper.Preferencias;
import com.doorman.porteirointeligente.helper.SlidingTabLayout;
import com.doorman.porteirointeligente.model.Contato;
import com.doorman.porteirointeligente.model.Respnao;
import com.doorman.porteirointeligente.model.Resposta;
import com.doorman.porteirointeligente.model.Usuario;


import com.doorman.porteirointeligente.model.Visitante;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import android.view.View;
import android.widget.AlphabetIndexer;
import android.widget.EditText;
import android.widget.Toast;


public class ApartamentoActivity extends AppCompatActivity {


    private FirebaseAuth usuarioFirebase;
    private SlidingTabLayout slidingTabLayout;
    private ViewPager viewPager;
    private DatabaseReference firebase;
    private Toolbar toolbar;
    private String identificadorContato;
    private DatabaseReference fire;
    private DatabaseReference comi;
    private DatabaseReference enco;
    private String sim = "Sim";
    private String nao = "Nao";

    ///////Resposta//////
    private DatabaseReference referecia = FirebaseDatabase.getInstance().getReference();




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_apartamento);

        usuarioFirebase = ConfiguracaoFirebase.getFirebaseAutenticacao();




       toolbar = (Toolbar) findViewById(R.id.toolbar);
       toolbar.setTitle("Porteiro Virtual");
       setSupportActionBar(toolbar);

        slidingTabLayout = (SlidingTabLayout) findViewById(R.id.stl_tabs);
        viewPager = (ViewPager) findViewById(R.id.vp_pagina);

        //Configurar sliding tabs
       slidingTabLayout.setDistributeEvenly(true);
       slidingTabLayout.setSelectedIndicatorColors(ContextCompat.getColor(this,R.color.Cor_Letra_Botão));

        //Configurar adapter
        TabAdapter tabAdapter = new TabAdapter( getSupportFragmentManager() );
        viewPager.setAdapter(tabAdapter);

        slidingTabLayout.setViewPager(viewPager);

          /////////////VISITANTE//////////////

    //Recuperar identificador usuario logado (base64)
    Preferencias preferencias = new Preferencias(ApartamentoActivity.this);
    final String identificadorUsuarioLog = preferencias.getIdentificador();

    //Recuperar instância Firebase
    fire = ConfiguracaoFirebase.getFirebase().child("visitantes").child("YWRtaW5AZ21haWwuY29t").child("ap");



        fire.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                if(dataSnapshot.getValue() != null){
                    //Instanciar AlertDialog
                    AlertDialog.Builder dialog = new AlertDialog.Builder(ApartamentoActivity.this);



                    //Configurar titulo e mensagem
                    dialog.setTitle("NOTIFICAÇÃO DE VISITANTE");
                    dialog.setMessage("Deseja permitir a entrada do(a) visitante Maria?");

                    //Configurar cancelamento
                    dialog.setCancelable(false);

                    //Configura acoes para sim e nao
                    dialog.setPositiveButton("Sim", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            //////////RESPOSTA PARA O VISITANTE - Sim////////////

                            DatabaseReference respsim =  referecia.child("respostasimvisi");

                            Resposta resposta = new Resposta();
                            resposta.setResp(sim);

                            respsim.child("001").setValue(resposta);



                            ///////////////////

                            Toast.makeText(
                                    getApplicationContext(),
                                    "O portão será aberto para o visistante",
                                    Toast.LENGTH_SHORT
                            ).show();

                        }
                    });

                    dialog.setNegativeButton("Não", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            //////////RESPOSTA PARA O VISITANTE - NAO////////////

                            DatabaseReference respostanao =  referecia.child("respostanaovisi");

                            Respnao respn = new Respnao();
                            respn.setResp(nao);

                            respostanao.child("001").setValue(respn);

                            Toast.makeText(
                                    getApplicationContext(),
                                    "O portão não será aberto",
                                    Toast.LENGTH_SHORT
                            ).show();

                        }
                    });

                    //Criar e exibir AlertDialog
                    dialog.create();
                    dialog.show();

                }


              }




            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


            ////////////COMIDA/////////////////

        //Recuperar identificador usuario logado (base64)
        //Preferencias preferencias = new Preferencias(ApartamentoActivity.this);
      //  final String identificadorUsuarioLog = preferencias.getIdentificador();

        //Recuperar instância Firebase
        comi = ConfiguracaoFirebase.getFirebase().child("comida").child("YWRtaW5AZ21haWwuY29t").child("ap");



        comi.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                if(dataSnapshot.getValue() != null){
                    //Instanciar AlertDialog
                    AlertDialog.Builder dialog = new AlertDialog.Builder(ApartamentoActivity.this);

                    //Configurar titulo e mensagem
                    dialog.setTitle("NOTIFICAÇÃO DE ENTREGA DE ALIMENTO");
                    dialog.setMessage("Confirme se a entrega esta correta!");

                    //Configurar cancelamento
                    dialog.setCancelable(false);

                    //Configura acoes para sim e nao
                    dialog.setPositiveButton("Sim, está correto!", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            //////////RESPOSTA PARA comida- Sim////////////

                            DatabaseReference comisim =  referecia.child("respcomisim");

                            Resposta resposta = new Resposta();
                            resposta.setResp(sim);

                            comisim.child("001").setValue(resposta);

                            Toast.makeText(
                                    getApplicationContext(),
                                    "Vá até a portaria para pegar!",
                                    Toast.LENGTH_SHORT
                            ).show();

                        }
                    });

                    dialog.setNegativeButton("Não, apartamento errado!", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            //////////RESPOSTA PARA O VISITANTE - NAO////////////

                            DatabaseReference respostanao =  referecia.child("respostacominao");

                            Respnao respn = new Respnao();
                            respn.setResp(nao);

                            respostanao.child("001").setValue(respn);

                            Toast.makeText(
                                    getApplicationContext(),
                                    "Desculpe o incomodo.",
                                    Toast.LENGTH_SHORT
                            ).show();

                        }
                    });

                    //Criar e exibir AlertDialog
                    dialog.create();
                    dialog.show();

                }


            }




            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });



        ///////////////ENCOMENDA///////////////

//Recuperar instância Firebase
        enco = ConfiguracaoFirebase.getFirebase().child("encomenda").child("YWRtaW5AZ21haWwuY29t").child("bloco");

        enco.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                if(dataSnapshot.getValue() != null){
                    //Instanciar AlertDialog
                    AlertDialog.Builder dialog = new AlertDialog.Builder(ApartamentoActivity.this);

                    //Configurar titulo e mensagem
                    dialog.setTitle("NOTIFICAÇÃO DE ENTREGA DE ENCOMENDA:");
                    dialog.setMessage("Confirme se a entrega esta correta!");

                    //Configurar cancelamento
                    dialog.setCancelable(false);

                    //Configura acoes para sim e nao
                    dialog.setPositiveButton("Sim, está correto!", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            //////////RESPOSTA PARA comida- Sim////////////

                            DatabaseReference encosim =  referecia.child("respencosim");

                            Resposta resposta = new Resposta();
                            resposta.setResp(sim);

                            encosim.child("001").setValue(resposta);


                            Toast.makeText(
                                    getApplicationContext(),
                                    "Vá até a portaria para pegar!",
                                    Toast.LENGTH_SHORT
                            ).show();

                        }
                    });

                    dialog.setNegativeButton("Não, apartamento errado!", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            //////////RESPOSTA PARA O VISITANTE - NAO////////////

                            DatabaseReference naoenco =  referecia.child("respostaenconao");

                            Respnao respn = new Respnao();
                            respn.setResp(nao);

                            naoenco.child("001").setValue(respn);

                            Toast.makeText(
                                    getApplicationContext(),
                                    "Desculpe o incomodo.",
                                    Toast.LENGTH_SHORT
                            ).show();

                        }
                    });

                    //Criar e exibir AlertDialog
                    dialog.create();
                    dialog.show();

                }


            }




            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

         /////////////////////
}

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_apartamento, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch ( item.getItemId() ){
            case R.id.item_sair :
                deslogarUsuario();
                return true;
            case R.id.item_adicionar :
                abrirCadastroContato();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void abrirCadastroContato(){

        AlertDialog.Builder alertDialog = new AlertDialog.Builder(ApartamentoActivity.this);


        //Configurações do Dialog
        alertDialog.setTitle("Novo contato");
        alertDialog.setMessage("E-mail do usuário");
        alertDialog.setCancelable(false);

        final EditText editText = new EditText(ApartamentoActivity.this);
        alertDialog.setView( editText );


        //Configura botões
        alertDialog.setPositiveButton("Cadastrar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                String emailContato = editText.getText().toString();


                //Valida se o e-mail foi digitado
                if( emailContato.isEmpty() ){
                    Toast.makeText(ApartamentoActivity.this, "Preencha o e-mail", Toast.LENGTH_LONG).show();
                }else{

                    //Verificar se o usuário já está cadastrado no nosso App
                    identificadorContato = Base64Custom.codificarBase64(emailContato);

                    //Recuperar instância Firebase
                    firebase = ConfiguracaoFirebase.getFirebase().child("usuarios").child(identificadorContato);

                    firebase.addListenerForSingleValueEvent(new ValueEventListener() {


                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {

                            if( dataSnapshot.getValue() != null ){

                                //Recuperar dados do contato a ser adicionado
                                Usuario usuarioContato = dataSnapshot.getValue( Usuario.class );

                                //Recuperar identificador usuario logado (base64)
                                Preferencias preferencias = new Preferencias(ApartamentoActivity.this);
                                String identificadorUsuarioLogado = preferencias.getIdentificador();

                                firebase = ConfiguracaoFirebase.getFirebase();
                                firebase = firebase.child("contatos")
                                        .child( identificadorUsuarioLogado )
                                        .child( identificadorContato );

                                Contato contato = new Contato();
                                contato.setIdentificadorUsuario( identificadorContato );
                                contato.setEmail( usuarioContato.getEmail() );
                                contato.setNome( usuarioContato.getNome() );

                                firebase.setValue( contato );



                            }else {
                                Toast.makeText(ApartamentoActivity.this, "Usuário não possui cadastro.", Toast.LENGTH_LONG)
                                        .show();
                            }

                        }

                        @Override
                        public void onCancelled(DatabaseError databaseError) {

                        }
                    });

                }

            }
        });

        alertDialog.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });

        alertDialog.create();
        alertDialog.show();

    }

    public void identificar(){

        String identifica = identificadorContato;


    }

    private void deslogarUsuario(){

        usuarioFirebase.signOut();

        Intent intent = new Intent(ApartamentoActivity.this, LoginActivity.class);
        startActivity(intent);
        finish();
    }




    }








