package com.doorman.porteirointeligente.model;


import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.doorman.porteirointeligente.Activity.VisitanteActivity;

import java.util.ArrayList;

public class Visitante {
    private String nome;
    private String bloco;
    private String ap;



    public Visitante() {

    }



    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getBloco() {
        return bloco;
    }

    public void setBloco(String bloco) {
        this.bloco = bloco;
    }

    public String getAp() {
        return ap;
    }

    public void setAp(String ap) {
        this.ap = ap;
    }

}


