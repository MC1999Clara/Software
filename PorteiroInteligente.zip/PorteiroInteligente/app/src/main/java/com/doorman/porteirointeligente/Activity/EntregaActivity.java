package com.doorman.porteirointeligente.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.doorman.porteirointeligente.R;
import com.doorman.porteirointeligente.config.ConfiguracaoFirebase;
import com.doorman.porteirointeligente.helper.Preferencias;
import com.doorman.porteirointeligente.model.Comida;
import com.doorman.porteirointeligente.model.Encomenda;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class EntregaActivity extends AppCompatActivity {

    /////COMIDA/////////
    private Button comida;
    private EditText bloco;
    private  EditText ap;
    private DatabaseReference sim;
    private  DatabaseReference nao;
    private DatabaseReference naoenco;
    private DatabaseReference simenco;

    private DatabaseReference referecia = FirebaseDatabase.getInstance().getReference();

    ////////ENTREGAS///////////
    private Button entrega;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_entrega);

        comida = (Button) findViewById(R.id.comida_btn);
        entrega = (Button) findViewById(R.id.entrega_brn);
        bloco = (EditText) findViewById(R.id.bloco_entregas);
        ap = (EditText) findViewById(R.id.ap_entregas);

        comida.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                DatabaseReference comidas =  referecia.child("comida");

                //Recuperar identificador usuario logado (base64)
                Preferencias preferencias = new Preferencias(EntregaActivity.this);

                final String identificadorUsuarioLogi = preferencias.getIdentificador();
                //String identificadorUsuarioLogi = preferencias.getIdentificador();

                Comida comida = new Comida();

                comida.setBloco(bloco.getText().toString());
                comida.setAp(ap.getText().toString());

                comidas.child(identificadorUsuarioLogi).setValue(comida);


                //Instanciar AlertDialog
                AlertDialog.Builder dialog = new AlertDialog.Builder(EntregaActivity.this);

                //Configurar titulo e mensagem
                dialog.setTitle("Notificação de entrega de COMIDA enviada com sucesso");
                dialog.setMessage("Aguarde a resposta do morador!");

                //Configurar cancelamento
                dialog.setCancelable(false);

                //Configurar icone
               // dialog.setIcon(android.R.drawable.ic_btn_speak_now);

                //Configura acoes para sim e nao
                dialog.setPositiveButton("ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        Toast.makeText(
                                getApplicationContext(),
                                "Aguarde...",
                                Toast.LENGTH_SHORT
                        ).show();



                    }
                });

                //Criar e exibir AlertDialog
                dialog.create();
                dialog.show();




            }
        });


        ///////////////RESPOSTA SIM////////////////////////

        //Recuperar instância Firebase
        sim= ConfiguracaoFirebase.getFirebase().child("respcomisim").child("001");

        sim.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.getValue() != null) {
                    //Instanciar AlertDialog
                    AlertDialog.Builder dialog = new AlertDialog.Builder(EntregaActivity.this);


                    //Configurar titulo e mensagem
                    dialog.setTitle("Notificação");
                    dialog.setMessage("Morador esta se dirigindo até a portaria!");

                    //Configurar cancelamento
                    dialog.setCancelable(false);

                    //Configura acoes para sim e nao
                    dialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            Toast.makeText(
                                    getApplicationContext(),
                                    "Aguarde...",
                                    Toast.LENGTH_SHORT
                            ).show();



                        }
                    });

                    //Criar e exibir AlertDialog
                    dialog.create();
                    dialog.show();


                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


        ///////////Resposta NAO/////////////////////

        //Recuperar instância Firebase
        nao= ConfiguracaoFirebase.getFirebase().child("respostacominao").child("001");

        nao.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.getValue() != null) {
                    //Instanciar AlertDialog
                    AlertDialog.Builder dialog = new AlertDialog.Builder(EntregaActivity.this);


                    //Configurar titulo e mensagem
                    dialog.setTitle("Notificação: Apartamento Incorreto!");
                    dialog.setMessage("Verifique se o apartamento e bloco estão corretos!");

                    //Configurar cancelamento
                    dialog.setCancelable(false);

                    //Configura acoes para sim e nao
                    dialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            Toast.makeText(
                                    getApplicationContext(),
                                    "Tente novamente!",
                                    Toast.LENGTH_SHORT
                            ).show();



                        }
                    });

                    //Criar e exibir AlertDialog
                    dialog.create();
                    dialog.show();


                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        entrega.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                        DatabaseReference encomendas  =  referecia.child("encomenda");

                        //Recuperar identificador usuario logado (base64)
                        Preferencias preferencias = new Preferencias(EntregaActivity.this);

                        final String identificadorUsuarioLogi = preferencias.getIdentificador();
                        //String identificadorUsuarioLogi = preferencias.getIdentificador();

                        Encomenda encomenda = new Encomenda();

                        encomenda.setBloco(bloco.getText().toString());
                        encomenda.setAp(ap.getText().toString());

                        encomendas.child(identificadorUsuarioLogi).setValue(encomenda);


                        //Instanciar AlertDialog
                        AlertDialog.Builder dialog = new AlertDialog.Builder(EntregaActivity.this);

                        //Configurar titulo e mensagem
                        dialog.setTitle("Notificação de ENCOMENDA enviada com sucesso");
                        dialog.setMessage("Aguarde a resposta do morador!");

                        //Configurar cancelamento
                        dialog.setCancelable(false);

                        //Configurar icone
                       // dialog.setIcon(android.R.drawable.ic_btn_speak_now);

                        //Configura acoes para sim e nao
                        dialog.setPositiveButton("ok", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                                Toast.makeText(
                                        getApplicationContext(),
                                        "Aguarde...",
                                        Toast.LENGTH_SHORT
                                ).show();



                            }
                        });

                        //Criar e exibir AlertDialog
                        dialog.create();
                        dialog.show();

                    }
                });

        ///////////////RESPOSTA SIM////////////////////////

        //Recuperar instância Firebase
        simenco= ConfiguracaoFirebase.getFirebase().child("respencosim").child("001");

        simenco.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.getValue() != null) {
                    //Instanciar AlertDialog
                    AlertDialog.Builder dialog = new AlertDialog.Builder(EntregaActivity.this);


                    //Configurar titulo e mensagem
                    dialog.setTitle("Notificação");
                    dialog.setMessage("Morador esta se dirigindo até a portaria!");

                    //Configurar cancelamento
                    dialog.setCancelable(false);

                    //Configura acoes para sim e nao
                    dialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            Toast.makeText(
                                    getApplicationContext(),
                                    "Aguarde...",
                                    Toast.LENGTH_SHORT
                            ).show();



                        }
                    });

                    //Criar e exibir AlertDialog
                    dialog.create();
                    dialog.show();


                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


        ///////////Resposta NAO/////////////////////

        //Recuperar instância Firebase
        naoenco= ConfiguracaoFirebase.getFirebase().child("respostaenconao").child("001");

        naoenco.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.getValue() != null) {
                    //Instanciar AlertDialog
                    AlertDialog.Builder dialog = new AlertDialog.Builder(EntregaActivity.this);


                    //Configurar titulo e mensagem
                    dialog.setTitle("Notificação: Apartamento Incorreto!");
                    dialog.setMessage("Verifique se o apartamento e bloco estão corretos!");

                    //Configurar cancelamento
                    dialog.setCancelable(false);

                    //Configura acoes para sim e nao
                    dialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            Toast.makeText(
                                    getApplicationContext(),
                                    "Tente novamente!",
                                    Toast.LENGTH_SHORT
                            ).show();



                        }
                    });

                    //Criar e exibir AlertDialog
                    dialog.create();
                    dialog.show();


                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


    }




}

